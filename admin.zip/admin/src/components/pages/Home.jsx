import { Typography } from "@mui/material";
import React from "react";

const Home: React.FC = () => {
  return <Typography variant="h1">Welcome back!!!</Typography>;
};
export default Home;
